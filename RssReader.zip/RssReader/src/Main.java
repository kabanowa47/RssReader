import java.net.URL;

import it.sauronsoftware.feed4j.FeedParser;
import it.sauronsoftware.feed4j.bean.Feed;
import it.sauronsoftware.feed4j.bean.FeedHeader;
import it.sauronsoftware.feed4j.bean.FeedItem;

public class Main {


    public static void main(String[] args){






            //System.out.println(RssEngine.readRSS("http://feeds.reuters.com/reuters/peopleNews"));
        }
}

